-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 06, 2022 at 10:45 PM
-- Server version: 5.7.32
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio_project_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `Portfolios`
--

CREATE TABLE `Portfolios` (
  `PortfolioID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `AboutSection` varchar(3000) DEFAULT NULL,
  `AboutImage` blob,
  `ProjectOneTitle` varchar(100) DEFAULT NULL,
  `ProjectOneDescription` varchar(1000) DEFAULT NULL,
  `ProjectOneImage` blob,
  `ProjectOneLink` varchar(100) DEFAULT NULL,
  `ProjectTwoTitle` varchar(100) DEFAULT NULL,
  `ProjectTwoDescription` varchar(1000) DEFAULT NULL,
  `ProjectTwoImage` blob,
  `ProjectTwoLink` varchar(100) DEFAULT NULL,
  `ProjectThreeTitle` varchar(100) DEFAULT NULL,
  `ProjectThreeDescription` varchar(1000) DEFAULT NULL,
  `ProjectThreeImage` blob,
  `ProjectThreeLink` varchar(100) DEFAULT NULL,
  `ResumeLink` varchar(200) DEFAULT NULL,
  `GithubLink` varchar(200) DEFAULT NULL,
  `LinkedInLink` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Portfolios`
--

INSERT INTO `Portfolios` (`PortfolioID`, `UserID`, `AboutSection`, `AboutImage`, `ProjectOneTitle`, `ProjectOneDescription`, `ProjectOneImage`, `ProjectOneLink`, `ProjectTwoTitle`, `ProjectTwoDescription`, `ProjectTwoImage`, `ProjectTwoLink`, `ProjectThreeTitle`, `ProjectThreeDescription`, `ProjectThreeImage`, `ProjectThreeLink`, `ResumeLink`, `GithubLink`, `LinkedInLink`, `Email`) VALUES
(1, 1, 'Hi there! My name is Andres. I am currently a software engineering student at the University of Nebraska-Lincoln. I am Nebraska-born and raised and a proud Husker! Over the past summer, I started interning at Sandhills Global where I got my first look at software engineering in the real world. The journey I have taken through college is nothing that I had imagined while in high school.\r\n\r\nI grew up in Crete, Nebraska with my mom and two sisters. While growing up, I found my passion for math, puzzles, and problem-solving. Once the time came to pick a major, I was unsure of what route to take. I decided on Accounting since I was currently taking one during my senior year. During my Freshman year of college, I found myself \"going through the motions\" in my business courses and spending the majority of my time digging deeper into Calculus 2 and Physics.\r\n\r\nDuring my second semester, I had an open slot for an elective. I decided to take an introductory class in C programming with some of my friends even though I had no prior experience. Similar to the previous semester, I was not enjoying my business courses as much as the technical courses. Halfway through the semester, I decided it was best to switch my major to software engineering. Since then, I have learned various topics such as numerous architectures, web development, and embedded systems.', NULL, 'Grant Tracker', 'The Grant Tracker is a project I am currently working on for my senior design project. My team is working with our sponsor to create a product they plan to use to assist them in grant distribution. This project uses React, Flask, and MongoDB.', NULL, NULL, 'Sorting Visualizer', 'At the start of my senior design project, my team did not have much experience with web development. I took this opportunity to familiarize myself with react to ensure my team was prepared for the web development aspect of our project. This project not only taught me the basics of web development, but it also required me to understand sorting algorithms in a new way. This project was completed using React.', NULL, 'https://andresruiz01.github.io/sorting-visualizer/', 'Oscilloscope', 'The oscilloscope was a project I completed within Advanced Embedded Systems. Enrolling in this course requiredme to get out of my comfort zone and learn about various hardware topics. Over the course of the semester, welearned about the various parts of an oscilloscope and how to create one. This project was created using VHDL,TeraTerm, and Nexys Video board.', NULL, 'https://bitbucket.org/arruiz/csce_436_ruiz/src/master/', 'https://onedrive.live.com/embed?cid=2E1561856C63F7DF&resid=2E1561856C63F7DF%21106&authkey=AHxvZ4rd-7AWkGA&em=2', 'https://github.com/AndresRuiz01', 'https://www.linkedin.com/in/andres-ruiz-870111225/', 'andres@test.com'),
(2, 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce id purus porta, mattis neque nec, ullamcorper turpis. Ut ultricies vestibulum felis nec euismod. Curabitur id ornare dolor. Nullam lorem nibh, ullamcorper ut ex nec, elementum posuere risus. Phasellus pharetra faucibus elementum. Nullam quis molestie nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed venenatis leo. Morbi dapibus lorem egestas ligula efficitur, vel blandit lorem porta. Curabitur sodales ac ligula eget tempus.\r\n\r\nAenean risus nunc, dapibus et consequat sed, imperdiet sed sapien. Nunc vitae ante ac lectus tincidunt ultricies eu eget urna. Ut aliquam elit neque, a hendrerit urna aliquam id. Nulla iaculis nunc nec erat laoreet, quis facilisis orci blandit. Proin aliquam quis ligula eleifend ultricies. Fusce tristique urna in ante vehicula, id hendrerit dui volutpat. Vestibulum nec augue urna. Praesent et est et nisi pharetra faucibus. Pellentesque sit amet venenatis mauris. Donec nec nisl a dui pellentesque interdum. Cras convallis, enim id aliquet varius, lacus sem tincidunt lacus, non tincidunt ligula est vitae lacus. Proin sit amet ex nec mi cursus placerat a a lectus. Sed justo velit, egestas ac mi quis, tincidunt suscipit neque.\r\n\r\nAliquam dictum ut purus et euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam placerat lectus id tortor congue suscipit. Etiam risus lorem, volutpat id pellentesque vel, tristique a dui. In fermentum, turpis nec congue consectetur, ex sapien vehicula erat, non lobortis velit diam in tortor. Sed blandit quam eu libero faucibus congue. Aliquam consequat maximus lorem, vitae eleifend purus pulvinar non.', NULL, 'Lorem Ipsum', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce id purus porta, mattis neque nec, ullamcorper turpis. Ut ultricies vestibulum felis nec euismod. Curabitur id ornare dolor. Nullam lorem nibh, ullamcorper ut ex nec, elementum posuere risus. Phasellus pharetra faucibus elementum. Nullam quis molestie nulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed venenatis leo. Morbi dapibus lorem egestas ligula efficitur, vel blandit lorem porta. Curabitur sodales ac ligula eget tempus.', NULL, NULL, 'Lorem Ipsum', 'Aenean risus nunc, dapibus et consequat sed, imperdiet sed sapien. Nunc vitae ante ac lectus tincidunt ultricies eu eget urna. Ut aliquam elit neque, a hendrerit urna aliquam id. Nulla iaculis nunc nec erat laoreet, quis facilisis orci blandit. Proin aliquam quis ligula eleifend ultricies. Fusce tristique urna in ante vehicula, id hendrerit dui volutpat. Vestibulum nec augue urna. Praesent et est et nisi pharetra faucibus. Pellentesque sit amet venenatis mauris. Donec nec nisl a dui pellentesque interdum. Cras convallis, enim id aliquet varius, lacus sem tincidunt lacus, non tincidunt ligula est vitae lacus. Proin sit amet ex nec mi cursus placerat a a lectus. Sed justo velit, egestas ac mi quis, tincidunt suscipit neque.', NULL, NULL, NULL, NULL, NULL, NULL, 'https://onedrive.live.com/embed?cid=2E1561856C63F7DF&resid=2E1561856C63F7DF%21106&authkey=AHxvZ4rd-7AWkGA&em=2', 'https://github.com/AndresRuiz01', NULL, 'jdoe@test.com'),
(3, 3, 'Aenean risus nunc, dapibus et consequat sed, imperdiet sed sapien. Nunc vitae ante ac lectus tincidunt ultricies eu eget urna. Ut aliquam elit neque, a hendrerit urna aliquam id. Nulla iaculis nunc nec erat laoreet, quis facilisis orci blandit. Proin aliquam quis ligula eleifend ultricies. Fusce tristique urna in ante vehicula, id hendrerit dui volutpat. Vestibulum nec augue urna. Praesent et est et nisi pharetra faucibus. Pellentesque sit amet venenatis mauris. Donec nec nisl a dui pellentesque interdum. Cras convallis, enim id aliquet varius, lacus sem tincidunt lacus, non tincidunt ligula est vitae lacus. Proin sit amet ex nec mi cursus placerat a a lectus. Sed justo velit, egestas ac mi quis, tincidunt suscipit neque.\r\n\r\nAenean risus nunc, dapibus et consequat sed, imperdiet sed sapien. Nunc vitae ante ac lectus tincidunt ultricies eu eget urna. Ut aliquam elit neque, a hendrerit urna aliquam id. Nulla iaculis nunc nec erat laoreet, quis facilisis orci blandit. Proin aliquam quis ligula eleifend ultricies. Fusce tristique urna in ante vehicula, id hendrerit dui volutpat. Vestibulum nec augue urna. Praesent et est et nisi pharetra faucibus. Pellentesque sit amet venenatis mauris. Donec nec nisl a dui pellentesque interdum. Cras convallis, enim id aliquet varius, lacus sem tincidunt lacus, non tincidunt ligula est vitae lacus. Proin sit amet ex nec mi cursus placerat a a lectus. Sed justo velit, egestas ac mi quis, tincidunt suscipit neque.', NULL, 'Lorem Ipsum', 'Aenean risus nunc, dapibus et consequat sed, imperdiet sed sapien. Nunc vitae ante ac lectus tincidunt ultricies eu eget urna. Ut aliquam elit neque, a hendrerit urna aliquam id. Nulla iaculis nunc nec erat laoreet, quis facilisis orci blandit. Proin aliquam quis ligula eleifend ultricies. Fusce tristique urna in ante vehicula, id hendrerit dui volutpat. Vestibulum nec augue urna. Praesent et est et nisi pharetra faucibus. Pellentesque sit amet venenatis mauris. Donec nec nisl a dui pellentesque interdum. Cras convallis, enim id aliquet varius, lacus sem tincidunt lacus, non tincidunt ligula est vitae lacus. Proin sit amet ex nec mi cursus placerat a a lectus. Sed justo velit, egestas ac mi quis, tincidunt suscipit neque.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'https://github.com/AndresRuiz01', 'randomlink.com', 'jdoe@test.com'),
(4, 5, 'test', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Occupation` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Pwd` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`UserID`, `FirstName`, `LastName`, `Occupation`, `Email`, `Pwd`) VALUES
(1, 'Andres', 'Ruiz', 'Software Engineer', 'andres@test.com', 'test'),
(2, 'John', 'Doe', 'Farmer', 'john@test.com', 'farmer123'),
(3, 'Jane', 'Doe', 'Electrical Engineer', 'jdoe@test.com', 'test'),
(4, 'Karl', 'Marx', 'Philosopher', 'kmarx@test.com', 'test'),
(5, 'test', 'test', 'tester', 'test@test1.com', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `Visits`
--

CREATE TABLE `Visits` (
  `VisitID` int(11) NOT NULL,
  `VisitingUserID` int(11) NOT NULL,
  `VisitedUserID` int(11) NOT NULL,
  `TimeVisited` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Visits`
--

INSERT INTO `Visits` (`VisitID`, `VisitingUserID`, `VisitedUserID`, `TimeVisited`) VALUES
(1, 1, 2, '2022-05-02 06:40:16'),
(2, 1, 2, '2022-05-02 06:45:07'),
(3, 1, 3, '2022-05-02 06:52:18'),
(5, 1, 2, '2022-05-02 07:05:52'),
(6, 1, 2, '2022-05-02 07:05:52'),
(7, 1, 3, '2022-05-02 07:06:55'),
(8, 1, 3, '2022-05-02 07:06:55'),
(9, 2, 1, '2022-05-02 07:38:11'),
(10, 2, 1, '2022-05-02 07:38:11'),
(11, 1, 3, '2022-05-02 07:47:12'),
(12, 1, 3, '2022-05-02 07:47:12'),
(13, 1, 2, '2022-05-02 07:47:16'),
(14, 1, 2, '2022-05-02 07:47:16'),
(15, 2, 3, '2022-05-02 07:48:19'),
(16, 2, 3, '2022-05-02 07:48:19'),
(17, 3, 1, '2022-05-02 07:48:41'),
(18, 3, 1, '2022-05-02 07:48:41'),
(19, 3, 2, '2022-05-02 07:48:43'),
(20, 1, 2, '2022-05-02 07:57:26'),
(21, 1, 2, '2022-05-02 07:57:26'),
(22, 1, 3, '2022-05-02 08:06:58'),
(23, 1, 3, '2022-05-02 08:06:58'),
(24, 1, 2, '2022-05-02 08:08:14'),
(25, 1, 2, '2022-05-02 08:08:14'),
(26, 2, 3, '2022-05-02 08:12:02'),
(27, 2, 3, '2022-05-02 08:12:02'),
(28, 3, 2, '2022-05-02 08:13:06'),
(29, 3, 2, '2022-05-02 08:13:06'),
(30, 3, 1, '2022-05-02 08:13:20'),
(31, 3, 1, '2022-05-02 08:13:20'),
(32, 4, 1, '2022-05-02 08:15:21'),
(33, 4, 1, '2022-05-02 08:15:21'),
(34, 4, 2, '2022-05-02 08:15:23'),
(35, 4, 2, '2022-05-02 08:15:23'),
(36, 4, 3, '2022-05-02 08:15:25'),
(37, 4, 3, '2022-05-02 08:15:25'),
(38, 1, 2, '2022-05-02 08:15:49'),
(39, 1, 2, '2022-05-02 08:15:49'),
(40, 1, 3, '2022-05-02 08:28:19'),
(41, 1, 3, '2022-05-02 08:28:19'),
(42, 1, 2, '2022-05-02 08:28:24'),
(43, 4, 2, '2022-05-02 08:31:59'),
(44, 4, 2, '2022-05-02 08:31:59'),
(45, 4, 3, '2022-05-02 08:32:02'),
(46, 4, 3, '2022-05-02 08:32:02'),
(47, 4, 1, '2022-05-02 08:32:04'),
(48, 4, 1, '2022-05-02 08:32:04'),
(49, 3, 2, '2022-05-02 08:32:14'),
(50, 3, 2, '2022-05-02 08:32:14'),
(51, 3, 1, '2022-05-02 08:32:16'),
(52, 3, 1, '2022-05-02 08:32:16'),
(53, 1, 2, '2022-05-02 08:35:18'),
(54, 1, 2, '2022-05-02 08:35:18'),
(55, 1, 3, '2022-05-02 08:35:25'),
(56, 1, 3, '2022-05-02 08:35:25'),
(57, 1, 2, '2022-05-02 09:24:23'),
(58, 1, 2, '2022-05-02 09:24:23'),
(59, 1, 3, '2022-05-02 09:24:26'),
(60, 1, 3, '2022-05-02 09:24:26'),
(61, 1, 2, '2022-05-02 09:40:11'),
(62, 1, 2, '2022-05-02 09:40:11'),
(63, 5, 1, '2022-05-02 09:41:05'),
(64, 5, 1, '2022-05-02 09:41:05'),
(65, 1, 2, '2022-05-05 14:20:05'),
(66, 1, 2, '2022-05-05 14:20:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Portfolios`
--
ALTER TABLE `Portfolios`
  ADD PRIMARY KEY (`PortfolioID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `Visits`
--
ALTER TABLE `Visits`
  ADD PRIMARY KEY (`VisitID`),
  ADD KEY `VisitingUserID` (`VisitingUserID`),
  ADD KEY `VisitedUserID` (`VisitedUserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Portfolios`
--
ALTER TABLE `Portfolios`
  MODIFY `PortfolioID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Visits`
--
ALTER TABLE `Visits`
  MODIFY `VisitID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Portfolios`
--
ALTER TABLE `Portfolios`
  ADD CONSTRAINT `portfolios_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Users` (`UserID`);

--
-- Constraints for table `Visits`
--
ALTER TABLE `Visits`
  ADD CONSTRAINT `visits_ibfk_1` FOREIGN KEY (`VisitingUserID`) REFERENCES `Users` (`UserID`),
  ADD CONSTRAINT `visits_ibfk_2` FOREIGN KEY (`VisitedUserID`) REFERENCES `Users` (`UserID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
